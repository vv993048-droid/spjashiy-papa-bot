Спящий Папа — Telegram AI бот (готов для группового чата)

В архиве:
- main.py            — основной скрипт бота
- db.py              — простая sqlite-обёртка (опционально, включена для расширения)
- tts.py             — Yandex SpeechKit TTS (aiohttp) + gTTS fallback
- config_example.yaml— пример конфига
- requirements.txt   — зависимости
- Dockerfile         — контейнеризация
- spyaschiy_papa.service — пример systemd unit
- start.sh           — стартер

Быстрый старт:
1) Скопируйте config_example.yaml -> config.yaml и вставьте TELEGRAM_BOT_TOKEN и YANDEX_API_KEY, укажите CHAT_ID.
2) Установите зависимости и запустите:
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   python main.py
3) Или соберите Docker-образ и запустите контейнер (см. Dockerfile).
