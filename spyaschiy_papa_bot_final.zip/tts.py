import aiohttp
import tempfile
import os
from gtts import gTTS
import asyncio

async def synthesize_text_yandex(text: str, api_key: str, voice: str = 'alena', fmt: str = 'mp3') -> str:
    """Использует Yandex Cloud SpeechKit (REST).
    Возвращает путь к аудиофайлу."""

    if not api_key:
        raise ValueError('YANDEX API KEY required')

    url = 'https://tts.api.cloud.yandex.net/speech/v1/tts:synthesize'
    headers = {'Authorization': f'Api-Key {api_key}'}
    data = {
        'text': text,
        'voice': voice,
        'format': fmt
    }
    fd, path = tempfile.mkstemp(suffix='.' + (fmt if fmt else 'mp3'))
    os.close(fd)
    timeout = aiohttp.ClientTimeout(total=60)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(url, data=data, headers=headers) as resp:
            if resp.status != 200:
                body = await resp.text()
                raise RuntimeError(f'Yandex TTS error: status={resp.status} body={body}')
            content = await resp.read()
            with open(path, 'wb') as f:
                f.write(content)
    return path

async def synthesize_text_gtts(text: str, lang: str = 'ru') -> str:
    """Fallback через gTTS (сохранение mp3)."""
    loop = asyncio.get_event_loop()
    fd, path = tempfile.mkstemp(suffix='.mp3')
    os.close(fd)
    def _save():
        tts = gTTS(text=text, lang=lang)
        tts.save(path)
    await loop.run_in_executor(None, _save)
    return path
