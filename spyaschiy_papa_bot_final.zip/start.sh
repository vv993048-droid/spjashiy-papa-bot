#!/bin/bash
if [ ! -f config.yaml ]; then
  echo "Please copy config_example.yaml -> config.yaml and edit it"
  exit 1
fi
exec python main.py
