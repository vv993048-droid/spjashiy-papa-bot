import asyncio
import random
import logging
import yaml
import os
from datetime import datetime
from aiogram import Bot, Dispatcher, types
from aiogram.types import FSInputFile
from tts import synthesize_text_yandex, synthesize_text_gtts
from db import MemoryDB

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Загрузка конфига
with open('config.yaml', 'r', encoding='utf-8') as f:
    cfg = yaml.safe_load(f)

TELEGRAM_TOKEN = cfg.get('TELEGRAM_BOT_TOKEN')
CHAT_ID = cfg.get('CHAT_ID')
YANDEX_KEY = cfg.get('YANDEX_API_KEY')
SLEEP_MODE = cfg.get('SLEEP_MODE', True)
SLEEP_START = cfg.get('SLEEP_START_HOUR', 23)
SLEEP_END = cfg.get('SLEEP_END_HOUR', 8)
WAKE_MIN = cfg.get('RANDOM_WAKE_MIN_SECONDS', 1800)
WAKE_MAX = cfg.get('RANDOM_WAKE_MAX_SECONDS', 5400)
VOICE = cfg.get('PREFERRED_VOICE', 'alena')
FMT = cfg.get('PREFERRED_FORMAT', 'oggopus')

if not TELEGRAM_TOKEN:
    raise SystemExit('TELEGRAM_BOT_TOKEN not set in config.yaml')
if not CHAT_ID:
    raise SystemExit('CHAT_ID not set in config.yaml')

bot = Bot(token=TELEGRAM_TOKEN)
dp = Dispatcher()

memory = MemoryDB('spyaschiy_papa.db')

def now_hour():
    return datetime.now().hour

def is_sleep_time():
    h = now_hour()
    if SLEEP_START <= SLEEP_END:
        return SLEEP_START <= h < SLEEP_END
    else:
        return h >= SLEEP_START or h < SLEEP_END

PAPA_PHRASES = [
    'Сын… не забудь… поменять масло… в 2035 году…',
    'Ты уверен… что это не пора?..',
    'Слушай… а где мой… эх, забыл…',
    'Запомни… главное… спать днём…',
    'Не наступай… на грабли… они злые…'
]

async def send_voice_to_chat(chat_id: int, text: str):
    # генерируем временный файл и отправляем как voice
    try:
        if YANDEX_KEY:
            path = await synthesize_text_yandex(text, api_key=YANDEX_KEY, voice=VOICE, fmt=FMT)
        else:
            path = await synthesize_text_gtts(text)
        # Telegram: send_voice expects OGG Opus for voice, send_audio accepts mp3
        # If format is mp3, we'll send as audio; if oggopus, send as voice
        if FMT and 'ogg' in FMT:
            with open(path, 'rb') as f:
                await bot.send_voice(chat_id=chat_id, voice=f, caption=text)
        else:
            with open(path, 'rb') as f:
                await bot.send_audio(chat_id=chat_id, audio=f, caption=text)
    finally:
        try:
            os.remove(path)
        except Exception:
            pass

@dp.message()
async def on_message(message: types.Message):
    # Работать только внутри указанного чата
    try:
        if message.chat.id != CHAT_ID:
            return
    except Exception:
        return

    text = (message.text or '')
    # Сохраняем небольшую заметку в память (пример использования базы)
    try:
        await memory.add_note(message.from_user.id, message.from_user.username or message.from_user.first_name, text[:1000])
    except Exception:
        logger.exception('DB write error')

    # Если бот в режиме сна и сейчас не время активности — молчим
    if SLEEP_MODE and not is_sleep_time():
        # Но реагируем на пробуждающую фразу
        if 'пробуди папу' in text.lower():
            await message.reply('...папа медленно просыпается...')
            await send_voice_to_chat(message.chat.id, 'Кто разбудил меня? Ах да... это вы.')
        return

    # Реагируем на упоминание слова 'папа' или обращение к боту
    if 'папа' in text.lower() or message.entities:
        # простая реакция
        phrase = random.choice(PAPA_PHRASES)
        await send_voice_to_chat(message.chat.id, phrase)
        return

    # Редко — папа само-реагирует
    if random.random() < 0.02:
        phrase = random.choice(PAPA_PHRASES)
        await send_voice_to_chat(message.chat.id, phrase)

async def random_waker():
    await memory.init()
    while True:
        delay = random.randint(WAKE_MIN, WAKE_MAX)
        await asyncio.sleep(delay)
        # Если только по ночам
        if SLEEP_MODE and not is_sleep_time():
            continue
        phrase = random.choice(PAPA_PHRASES)
        try:
            await send_voice_to_chat(CHAT_ID, phrase)
        except Exception:
            logger.exception('Failed to send random wake')

async def on_startup():
    await memory.init()
    asyncio.create_task(random_waker())
    logger.info('Spyaschiy Papa started')

if __name__ == '__main__':
    try:
        dp.run_polling(bot, on_startup=on_startup)
    except KeyboardInterrupt:
        logger.info('Stopping')
