import aiosqlite

class MemoryDB:
    def __init__(self, path: str):
        self.path = path
        self._conn = None

    async def init(self):
        self._conn = await aiosqlite.connect(self.path)
        await self._conn.executescript("""
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY,
            user_id INTEGER,
            username TEXT,
            content TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        await self._conn.commit()

    async def add_note(self, user_id: int, username: str, content: str):
        await self._conn.execute(
            "INSERT INTO notes (user_id, username, content) VALUES (?, ?, ?)",
            (user_id, username, content)
        )
        await self._conn.commit()

    async def get_random_note_by_user(self, user_id: int):
        cur = await self._conn.execute(
            "SELECT content FROM notes WHERE user_id = ? ORDER BY RANDOM() LIMIT 1",
            (user_id,)
        )
        row = await cur.fetchone()
        return row[0] if row else None

    async def close(self):
        if self._conn:
            await self._conn.close()
